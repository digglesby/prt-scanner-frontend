
  const page = require("./_error.original.js");
  const handlerFactory = require("./handler.js");

  module.exports.render = async (event, context) => {
    const handler = handlerFactory(page);
    const responsePromise = handler(event, context);
    return responsePromise;
  };
